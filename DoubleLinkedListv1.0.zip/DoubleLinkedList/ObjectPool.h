#pragma once
#include "Node.h"

template<typename T>
class ObjectPool
{
public:
	ObjectPool();
	~ObjectPool();

	ActiveList();
	InactiveList();
	Get();
	Release();
	Clear();
private:
	Node<T>* m_list
};

template<typename T>
inline ObjectPool<T>::ObjectPool()
{
}

template<typename T>
inline ObjectPool<T>::~ObjectPool()
{
}

template<typename T>
inline ObjectPool<T>::ActiveList()
{

}

template<typename T>
inline ObjectPool<T>::InactiveList()
{

}

template<typename T>
inline ObjectPool<T>::Get()
{

}

template<typename T>
inline ObjectPool<T>::Release()
{

}

template<typename T>
inline ObjectPool<T>::Clear()
{

}
