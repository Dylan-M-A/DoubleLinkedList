#pragma once
#include "Node.h"

template<typename T>
class TextureManager
{
public:
	TextureManager();
	~TextureManager();


};
